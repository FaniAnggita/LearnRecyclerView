package com.example.fanianggita.recyclerview.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.fanianggita.recyclerview.R
import com.example.fanianggita.recyclerview.model.Affirmation

// Parameter private val dataset: List<Affirmation> pada konstruktor ItemAdapte supaya dapat meneruskan daftar afirmasi ke adaptor.
// ItemAdapter memerlukan informasi tentang cara menyelesaikan resource string. Informasi ini, dan informasi lainnya tentang aplikasi, disimpan dalam instance objek Context yang dapat Anda teruskan ke instance ItemAdapter.
class ItemAdapter(
    private val context: Context,
    private val dataset: List<Affirmation>
) : RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {

    /*
    Metode onCreateViewHolder()dipanggil oleh pengelola tata letak untuk membuat holder tampilan baru untuk RecyclerView
    (saat tidak ada holder tampilan yang ada yang dapat digunakan kembali).
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        // create a new view
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    /*
     Metode ini dipanggil oleh pengelola tata letak untuk mengganti isi tampilan item daftar.
    */
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.textView.text = context.resources.getString(item.stringResourceId)
        holder.imageView.setImageResource(item.imageResourceId)
    }

    // menampilkan ukuran set data Anda. Data aplikasi Anda berada di properti dataset yang Anda berikan ke konstruktor ItemAdapter, dan Anda bisa mendapatkan ukurannya dengan size.
    override fun getItemCount() = dataset.size

    // subclass dari RecyclerView. ViewHolder dan meneruskan parameter view ke dalam konstruktor superclass.
    class ItemViewHolder(private val view: View): RecyclerView.ViewHolder(view) {
        val textView: TextView = view.findViewById(R.id.item_title)
        val imageView: ImageView = view.findViewById(R.id.item_image)
    }
}