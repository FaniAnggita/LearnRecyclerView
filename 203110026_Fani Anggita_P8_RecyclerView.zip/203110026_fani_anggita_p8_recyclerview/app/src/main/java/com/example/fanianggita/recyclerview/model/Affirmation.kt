package com.example.fanianggita.recyclerview.model


    /*
        1. Apabila kelas ini belum memiliki properti, maka akan terjadi error.
        2. Untuk mengatasi error tersebut kita tambahkan ID resource untuk string afirmasi dengan tipe bilangan bulat
           ke konstruktor class Affirmation, seperti di baris 9.
    */
data class Affirmation(val stringResourceId: Int) {

}