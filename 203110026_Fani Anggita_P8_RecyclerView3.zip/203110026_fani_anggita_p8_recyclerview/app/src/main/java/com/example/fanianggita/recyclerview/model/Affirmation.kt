package com.example.fanianggita.recyclerview.model


    /*
        1. Apabila kelas ini belum memiliki properti, maka akan terjadi error.
        2. Untuk mengatasi error tersebut kita tambahkan ID resource untuk string afirmasi dengan tipe bilangan bulat
           ke konstruktor class Affirmation, seperti di baris 9.
    */
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

// TODO 2: Menyiapkan tipe data afirmasi dan gambarnya
data class Affirmation(
    @StringRes val stringResourceId: Int,
    @DrawableRes val imageResourceId: Int
)